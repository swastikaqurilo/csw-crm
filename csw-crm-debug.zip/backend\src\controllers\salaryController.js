const mongoose = require("mongoose");
const Salary = require("../models/Salary");
const { Worker, Attendance } = require("../models/Worker");
const ProductProduction = require("../models/Product");
const { getGlobalSettings } = require("../utils/getSettings");

const {
  SALARY_DAY_DIVISOR,
  SIZES,
  REEL_WEIGHTS,
  isValidId,
  safeString,
  roundMoney,
  calculateNetSalary,
  calculatePaymentStatus,
  startOfDay,
  endOfDay,
  getDateString,
  getDaysBetween,
  isWorkingDay,
  toMinutes,
} = require("../utils/salary");

const createSalary = async (req, res) => {
  try {
    const {
      worker,
      periodStart,
      periodEnd,
      basicSalary,
      allowances = 0,
      deductions = 0,
      notes = "",
    } = req.body;

    if (!isValidId(worker)) {
      return res.status(400).json({
        success: false,
        message: "Valid worker is required",
      });
    }

    if (!periodStart || !periodEnd) {
      return res.status(400).json({
        success: false,
        message: "Salary period start and end dates are required",
      });
    }

    const start = new Date(periodStart);
    const end = new Date(periodEnd);

    if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) {
      return res.status(400).json({
        success: false,
        message: "Invalid salary period dates",
      });
    }

    if (start > end) {
      return res.status(400).json({
        success: false,
        message: "Period start date cannot be after period end date",
      });
    }

    const selectedWorker = await Worker.findById(worker);

    if (!selectedWorker) {
      return res.status(404).json({
        success: false,
        message: "Worker not found",
      });
    }

    const basic = Number(basicSalary);

    if (!Number.isFinite(basic) || basic < 0) {
      return res.status(400).json({
        success: false,
        message: "Valid basic salary is required",
      });
    }

    const allowance = Number(allowances) || 0;
    const deduction = Number(deductions) || 0;

    if (allowance < 0 || deduction < 0) {
      return res.status(400).json({
        success: false,
        message: "Allowances and deductions cannot be negative",
      });
    }

    const netSalary = calculateNetSalary(basic, allowance, deduction);

    // Exact duplicate
    const exact = await Salary.findOne({
      worker,
      periodStart: start,
      periodEnd: end,
      isDeleted: false,
    });

    if (exact) {
      return res.status(409).json({
        success: false,
        message: "Salary record already exists for this worker and period",
      });
    }

    // Overlap check — half-open interval: [start, end] vs [otherStart, otherEnd]
    // Overlap iff other.periodStart < end AND other.periodEnd > start
    const overlapping = await Salary.findOne({
      worker,
      isDeleted: false,
      periodStart: { $lt: end },
      periodEnd: { $gt: start },
    });

    if (overlapping) {
      const os = overlapping.periodStart.toISOString().slice(0, 10);
      const oe = overlapping.periodEnd.toISOString().slice(0, 10);
      return res.status(409).json({
        success: false,
        message: `Period overlaps an existing salary record (${os} → ${oe}).`,
      });
    }

    const salary = await Salary.create({
      worker,
      payType: selectedWorker.payType,
      periodStart: start,
      periodEnd: end,
      basicSalary: basic,
      allowances: allowance,
      deductions: deduction,
      netSalary,
      paidAmount: 0,
      paymentStatus: "Pending",
      notes: safeString(notes),
    });

    const populatedSalary = await Salary.findById(salary._id).populate(
      "worker",
      "workerId name phone role department payType fixedPay"
    );

    return res.status(201).json({
      success: true,
      message: "Salary record created successfully",
      data: populatedSalary,
    });
  } catch (error) {
    console.error("[createSalary]", error);

    return res.status(500).json({
      success: false,
      message: "Failed to create salary record",
      error: error.message,
    });
  }
};

/* ------------------------------------------------------------------ */
/*  LIST                                                               */
/* ------------------------------------------------------------------ */

const getSalaries = async (req, res) => {
  try {
    const {
      worker,
      paymentStatus,
      fromDate,
      toDate,
      page = 1,
      limit = 20,
      search = "",
    } = req.query;

    const filter = { isDeleted: false };

    if (worker) {
      if (!isValidId(worker)) {
        return res.status(400).json({
          success: false,
          message: "Invalid worker ID",
        });
      }
      filter.worker = worker;
    }

    if (paymentStatus) {
      filter.paymentStatus = paymentStatus;
    }

    if (fromDate || toDate) {
      filter.periodStart = {};

      if (fromDate) {
        const start = new Date(fromDate);
        if (Number.isNaN(start.getTime())) {
          return res.status(400).json({
            success: false,
            message: "Invalid fromDate",
          });
        }
        filter.periodStart.$gte = start;
      }

      if (toDate) {
        const end = new Date(toDate);
        if (Number.isNaN(end.getTime())) {
          return res.status(400).json({
            success: false,
            message: "Invalid toDate",
          });
        }
        filter.periodStart.$lte = end;
      }
    }

    const pageNumber = Math.max(Number(page) || 1, 1);
    const limitNumber = Math.min(Math.max(Number(limit) || 20, 1), 100);
    const skip = (pageNumber - 1) * limitNumber;

    if (search && String(search).trim()) {
      const workerIds = await Worker.find({
        name: {
          $regex: safeString(search, 100),
          $options: "i",
        },
      }).select("_id");

      const ids = workerIds.map((item) => item._id);

      if (filter.worker) {
        const requested = filter.worker;
        const match = ids.some((id) => String(id) === String(requested));

        if (!match) {
          return res.status(200).json({
            success: true,
            salaries: [],
            summary: {
              net: 0,
              paid: 0,
              advance: 0,
              outstanding: 0,
              open: 0,
            },
            pagination: {
              page: pageNumber,
              limit: limitNumber,
              total: 0,
              totalPages: 0,
            },
          });
        }
      } else {
        filter.worker = { $in: ids };
      }
    }

    const [salaries, total, summaryAgg] = await Promise.all([
      Salary.find(filter)
        .populate(
          "worker",
          "workerId name phone role department payType fixedPay"
        )
        .sort({ periodStart: -1, createdAt: -1 })
        .skip(skip)
        .limit(limitNumber),

      Salary.countDocuments(filter),

      Salary.aggregate([
        { $match: filter },
        {
          $group: {
            _id: null,
            net: { $sum: "$netSalary" },
            paid: { $sum: "$paidAmount" },
            advance: { $sum: "$advanceAmount" },
            open: {
              $sum: { $cond: [{ $ne: ["$paymentStatus", "Paid"] }, 1, 0] },
            },
          },
        },
      ]),
    ]);

    const s = summaryAgg[0] || { net: 0, paid: 0, advance: 0, open: 0 };

    return res.status(200).json({
      success: true,
      salaries,
      summary: {
        net: s.net || 0,
        paid: s.paid || 0,
        advance: s.advance || 0,
        outstanding: Math.max(
          0,
          (s.net || 0) - (s.paid || 0) - (s.advance || 0)
        ),
        open: s.open || 0,
      },
      pagination: {
        page: pageNumber,
        limit: limitNumber,
        total,
        totalPages: Math.ceil(total / limitNumber) || 1,
      },
    });
  } catch (error) {
    console.error("[getSalaries]", error);

    return res.status(500).json({
      success: false,
      message: "Failed to fetch salaries",
      error: error.message,
    });
  }
};

/* ------------------------------------------------------------------ */
/*  GET ONE                                                            */
/* ------------------------------------------------------------------ */

const getSalary = async (req, res) => {
  try {
    const { id } = req.params;

    if (!isValidId(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid salary ID",
      });
    }

    const salary = await Salary.findOne({
      _id: id,
      isDeleted: false,
    }).populate(
      "worker",
      "workerId name phone role department payType fixedPay"
    );

    if (!salary) {
      return res.status(404).json({
        success: false,
        message: "Salary record not found",
      });
    }

    return res.status(200).json({
      success: true,
      salary,
    });
  } catch (error) {
    console.error("[getSalary]", error);

    return res.status(500).json({
      success: false,
      message: "Failed to fetch salary",
      error: error.message,
    });
  }
};

/* ------------------------------------------------------------------ */
/*  UPDATE                                                             */
/* ------------------------------------------------------------------ */

const updateSalary = async (req, res) => {
  try {
    const { id } = req.params;

    if (!isValidId(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid salary ID",
      });
    }

    const salary = await Salary.findOne({
      _id: id,
      isDeleted: false,
    });

    if (!salary) {
      return res.status(404).json({
        success: false,
        message: "Salary record not found",
      });
    }

    const {
      periodStart,
      periodEnd,
      basicSalary,
      allowances,
      deductions,
      notes,
    } = req.body;

    const start = periodStart ? new Date(periodStart) : salary.periodStart;
    const end = periodEnd ? new Date(periodEnd) : salary.periodEnd;

    if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) {
      return res.status(400).json({
        success: false,
        message: "Invalid salary period dates",
      });
    }

    if (start > end) {
      return res.status(400).json({
        success: false,
        message: "Period start date cannot be after period end date",
      });
    }

    // If the period changed, re-check for overlap against other records
    const periodChanged =
      start.getTime() !== salary.periodStart.getTime() ||
      end.getTime() !== salary.periodEnd.getTime();

    if (periodChanged) {
      const overlapping = await Salary.findOne({
        _id: { $ne: salary._id },
        worker: salary.worker,
        isDeleted: false,
        periodStart: { $lt: end },
        periodEnd: { $gt: start },
      });

      if (overlapping) {
        const os = overlapping.periodStart.toISOString().slice(0, 10);
        const oe = overlapping.periodEnd.toISOString().slice(0, 10);
        return res.status(409).json({
          success: false,
          message: `New period overlaps an existing salary record (${os} → ${oe}).`,
        });
      }
    }

    const basic =
      basicSalary !== undefined ? Number(basicSalary) : salary.basicSalary;
    const allowance =
      allowances !== undefined ? Number(allowances) : salary.allowances;
    const deduction =
      deductions !== undefined ? Number(deductions) : salary.deductions;

    if (!Number.isFinite(basic) || basic < 0) {
      return res.status(400).json({
        success: false,
        message: "Invalid basic salary",
      });
    }

    if (
      !Number.isFinite(allowance) ||
      allowance < 0 ||
      !Number.isFinite(deduction) ||
      deduction < 0
    ) {
      return res.status(400).json({
        success: false,
        message: "Allowances and deductions cannot be negative",
      });
    }

    const netSalary = calculateNetSalary(basic, allowance, deduction);

    const totalCommitted =
      Number(salary.paidAmount || 0) + Number(salary.advanceAmount || 0);

    if (netSalary < totalCommitted) {
      return res.status(400).json({
        success: false,
        message:
          "Net salary cannot be lower than the combined amount already paid and advanced",
      });
    }

    salary.periodStart = start;
    salary.periodEnd = end;
    salary.basicSalary = basic;
    salary.allowances = allowance;
    salary.deductions = deduction;
    salary.netSalary = netSalary;

    if (notes !== undefined) {
      salary.notes = safeString(notes);
    }

    salary.paymentStatus = calculatePaymentStatus(
      netSalary,
      salary.paidAmount,
      salary.advanceAmount
    );

    await salary.save();

    const populatedSalary = await Salary.findById(salary._id).populate(
      "worker",
      "workerId name phone role department payType fixedPay"
    );

    return res.status(200).json({
      success: true,
      message: "Salary updated successfully",
      salary: populatedSalary,
    });
  } catch (error) {
    console.error("[updateSalary]", error);

    return res.status(500).json({
      success: false,
      message: "Failed to update salary",
      error: error.message,
    });
  }
};

/* ------------------------------------------------------------------ */
/*  RECORD PAYMENT                                                     */
/* ------------------------------------------------------------------ */

const recordSalaryPayment = async (req, res) => {
  const session = await mongoose.startSession();

  try {
    const { id } = req.params;

    const {
      amount,
      paymentDate = new Date(),
      paymentMode,
      transactionId = "",
      notes = "",
    } = req.body;

    if (!isValidId(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid salary ID",
      });
    }

    const paymentAmount = Number(amount);

    if (!Number.isFinite(paymentAmount) || paymentAmount <= 0) {
      return res.status(400).json({
        success: false,
        message: "Payment amount must be greater than zero",
      });
    }

    const validModes = [
      "Cash",
      "UPI",
      "Bank Transfer",
      "Cheque",
      "NEFT",
      "RTGS",
      "Other",
    ];

    if (!validModes.includes(paymentMode)) {
      return res.status(400).json({
        success: false,
        message: "Valid payment mode is required",
      });
    }

    const cleanTransactionId = safeString(transactionId, 150);

    if (
      ["UPI", "Bank Transfer", "NEFT", "RTGS", "Cheque"].includes(
        paymentMode
      ) &&
      !cleanTransactionId
    ) {
      return res.status(400).json({
        success: false,
        message: `Transaction/reference ID is required for ${paymentMode}`,
      });
    }

    const parsedPaymentDate = new Date(paymentDate);

    if (Number.isNaN(parsedPaymentDate.getTime())) {
      return res.status(400).json({
        success: false,
        message: "Invalid payment date",
      });
    }

    let paymentEntry;

    await session.withTransaction(async () => {
      const salary = await Salary.findOne({
        _id: id,
        isDeleted: false,
      }).session(session);

      if (!salary) {
        const error = new Error("Salary record not found");
        error.statusCode = 404;
        throw error;
      }

      const netSalary = Number(salary.netSalary || 0);
      const paidAmount = Number(salary.paidAmount || 0);
      const advanceAmount = Number(salary.advanceAmount || 0);

      const remainingAmount = netSalary - paidAmount - advanceAmount;

      if (paymentAmount > remainingAmount + 0.001) {
        const error = new Error(
          `Payment cannot exceed remaining salary of ₹${remainingAmount}`
        );
        error.statusCode = 400;
        throw error;
      }

      salary.payments.push({
        amount: paymentAmount,
        paymentDate: parsedPaymentDate,
        paymentMode,
        transactionId: cleanTransactionId,
        notes: safeString(notes, 500),
      });

      salary.paidAmount = paidAmount + paymentAmount;

      salary.paymentStatus = calculatePaymentStatus(
        salary.netSalary,
        salary.paidAmount,
        salary.advanceAmount
      );

      salary.lastPaymentDate = parsedPaymentDate;

      await salary.save({ session });

      paymentEntry = salary.payments[salary.payments.length - 1];
    });

    const populatedSalary = await Salary.findById(id).populate(
      "worker",
      "workerId name phone role department payType fixedPay"
    );

    return res.status(200).json({
      success: true,
      message: "Salary payment recorded successfully",
      salary: populatedSalary,
      payment: paymentEntry,
    });
  } catch (error) {
    console.error("[recordSalaryPayment]", error);

    if (error.statusCode === 400 || error.statusCode === 404) {
      return res.status(error.statusCode).json({
        success: false,
        message: error.message,
      });
    }

    return res.status(500).json({
      success: false,
      message: "Failed to record salary payment",
      error: error.message,
    });
  } finally {
    await session.endSession();
  }
};

/* ------------------------------------------------------------------ */
/*  RECORD ADVANCE                                                     */
/* ------------------------------------------------------------------ */

const recordSalaryAdvance = async (req, res) => {
  const session = await mongoose.startSession();

  try {
    const { id } = req.params;

    const {
      amount,
      date = new Date(),
      paymentMode = "Cash",
      transactionId = "",
      notes = "",
    } = req.body;

    if (!isValidId(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid salary ID",
      });
    }

    const advanceAmount = Number(amount);

    if (!Number.isFinite(advanceAmount) || advanceAmount <= 0) {
      return res.status(400).json({
        success: false,
        message: "Advance amount must be greater than zero",
      });
    }

    const validModes = [
      "Cash",
      "UPI",
      "Bank Transfer",
      "Cheque",
      "NEFT",
      "RTGS",
      "Other",
    ];

    if (!validModes.includes(paymentMode)) {
      return res.status(400).json({
        success: false,
        message: "Valid payment mode is required",
      });
    }

    const cleanTransactionId = safeString(transactionId, 150);

    if (
      ["UPI", "Bank Transfer", "NEFT", "RTGS", "Cheque"].includes(paymentMode) &&
      !cleanTransactionId
    ) {
      return res.status(400).json({
        success: false,
        message: `Transaction/reference ID is required for ${paymentMode}`,
      });
    }

    const parsedDate = new Date(date);
    if (Number.isNaN(parsedDate.getTime())) {
      return res.status(400).json({
        success: false,
        message: "Invalid advance date",
      });
    }

    let advanceEntry = null;

    await session.withTransaction(async () => {
      const salary = await Salary.findOne({
        _id: id,
        isDeleted: false,
      }).session(session);

      if (!salary) {
        const err = new Error("Salary record not found");
        err.statusCode = 404;
        throw err;
      }

      const netSalary = Number(salary.netSalary || 0);
      const paidAmount = Number(salary.paidAmount || 0);
      const advanceSoFar = Number(salary.advanceAmount || 0);

      const remaining = netSalary - paidAmount - advanceSoFar;

      if (advanceAmount > remaining + 0.001) {
        const err = new Error(
          `Advance cannot exceed the remaining balance of ₹${remaining.toFixed(2)}`
        );
        err.statusCode = 400;
        throw err;
      }

      salary.advances.push({
        amount: advanceAmount,
        date: parsedDate,
        paymentMode,
        transactionId: cleanTransactionId,
        notes: safeString(notes, 500),
        givenBy: req.user?._id || null,
      });

      salary.advanceAmount = advanceSoFar + advanceAmount;

      salary.paymentStatus = calculatePaymentStatus(
        salary.netSalary,
        salary.paidAmount,
        salary.advanceAmount
      );

      await salary.save({ session });

      advanceEntry = salary.advances[salary.advances.length - 1];
    });

    const populated = await Salary.findById(id).populate(
      "worker",
      "workerId name phone role department payType fixedPay variablePay"
    );

    return res.status(201).json({
      success: true,
      message: "Advance recorded successfully",
      salary: populated,
      advance: advanceEntry,
    });
  } catch (error) {
    console.error("[recordSalaryAdvance]", error);

    if (error.statusCode === 400 || error.statusCode === 404) {
      return res.status(error.statusCode).json({
        success: false,
        message: error.message,
      });
    }

    if (error.name === "ValidationError") {
      const msg = Object.values(error.errors).map((e) => e.message).join("; ");
      return res.status(400).json({ success: false, message: msg });
    }

    if (error.name === "CastError") {
      return res.status(400).json({
        success: false,
        message: `Invalid value for ${error.path}`,
      });
    }

    return res.status(500).json({
      success: false,
      message: "Failed to record advance",
      error: error.message,
    });
  } finally {
    await session.endSession();
  }
};

/* ------------------------------------------------------------------ */
/*  DELETE ADVANCE                                                     */
/* ------------------------------------------------------------------ */

const deleteSalaryAdvance = async (req, res) => {
  const session = await mongoose.startSession();

  try {
    const { id, advanceId } = req.params;

    if (!isValidId(id) || !isValidId(advanceId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid ID",
      });
    }

    let updated = null;

    await session.withTransaction(async () => {
      const salary = await Salary.findOne({
        _id: id,
        isDeleted: false,
      }).session(session);

      if (!salary) {
        const err = new Error("Salary record not found");
        err.statusCode = 404;
        throw err;
      }

      const adv = salary.advances.id(advanceId);
      if (!adv) {
        const err = new Error("Advance not found");
        err.statusCode = 404;
        throw err;
      }

      if (Number(salary.paidAmount) > 0) {
        const err = new Error(
          "Cannot delete advance — regular salary payments already exist"
        );
        err.statusCode = 400;
        throw err;
      }

      const removed = Number(adv.amount) || 0;
      adv.deleteOne();

      salary.advanceAmount = Math.max(
        Number(salary.advanceAmount || 0) - removed,
        0
      );

      salary.paymentStatus = calculatePaymentStatus(
        salary.netSalary,
        salary.paidAmount,
        salary.advanceAmount
      );

      await salary.save({ session });
      updated = salary;
    });

    return res.status(200).json({
      success: true,
      message: "Advance deleted successfully",
      salary: updated,
    });
  } catch (error) {
    console.error("[deleteSalaryAdvance]", error);

    if (error.statusCode === 400 || error.statusCode === 404) {
      return res.status(error.statusCode).json({
        success: false,
        message: error.message,
      });
    }

    return res.status(500).json({
      success: false,
      message: "Failed to delete advance",
      error: error.message,
    });
  } finally {
    await session.endSession();
  }
};

const deleteSalary = async (req, res) => {
  try {
    const { id } = req.params;

    if (!isValidId(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid salary ID",
      });
    }

    const salary = await Salary.findOne({
      _id: id,
      isDeleted: false,
    }).select("paidAmount advanceAmount");

    if (!salary) {
      return res.status(404).json({
        success: false,
        message: "Salary record not found",
      });
    }

    if (Number(salary.paidAmount) > 0) {
      return res.status(400).json({
        success: false,
        message: "Paid or partially paid salary records cannot be deleted",
      });
    }

    if (Number(salary.advanceAmount) > 0) {
      return res.status(400).json({
        success: false,
        message:
          "Salary records with advances cannot be deleted. Delete the advances first.",
      });
    }

    await Salary.updateOne(
      { _id: id, isDeleted: false },
      { $set: { isDeleted: true, deletedAt: new Date() } }
    );

    return res.status(200).json({
      success: true,
      message: "Salary deleted successfully",
    });
  } catch (error) {
    console.error("[deleteSalary]", error);

    return res.status(500).json({
      success: false,
      message: "Failed to delete salary",
      error: error.message,
    });
  }
};

const calculateFixedSalary = async ({
  worker,
  periodStart,
  periodEnd,
  settings,
}) => {
  const joiningDate = startOfDay(worker.joiningDate);
  const effectiveStart =
    joiningDate > periodStart ? joiningDate : periodStart;

  const fullPeriodWorkingDays = getDaysBetween(periodStart, periodEnd).filter(
    isWorkingDay
  ).length;

  const employedDates = getDaysBetween(effectiveStart, periodEnd).filter(
    isWorkingDay
  );
  const workingDays = employedDates.length;

  if (workingDays <= 0) {
    return {
      basicSalary: 0,
      attendance: {
        workingDays: 0,
        fullPeriodWorkingDays,
        presentDays: 0,
        absentDays: 0,
        halfDays: 0,
        dailyRate: 0,
        absenceDeduction: 0,
        proratedBase: 0,
        employedRatio: 0,
      },
    };
  }

  const attendanceDocs = await Attendance.find({
    date: {
      $gte: getDateString(effectiveStart),
      $lte: getDateString(periodEnd),
    },
  }).select("date allPresent absentWorkers records");

  const attendanceMap = new Map();
  for (const attendance of attendanceDocs) {
    attendanceMap.set(attendance.date, attendance);
  }

  const resolved = settings || (await getGlobalSettings());
  const policy = resolved?.attendance || {};

  const lateCutoff = toMinutes(policy.lateLoginCutoff || "09:30");
  const earlyCutoff = toMinutes(policy.earlyLogoutCutoff || "18:00");

  if (lateCutoff === null || earlyCutoff === null) {
    console.warn(
      "[calculateFixedSalary] Invalid cutoff in settings — late/early checks disabled for this run",
      {
        lateLoginCutoff: policy.lateLoginCutoff,
        earlyLogoutCutoff: policy.earlyLogoutCutoff,
      }
    );
  }

  let absentDays = 0;
  let halfDays = 0;

  for (const date of employedDates) {
    const dateString = getDateString(date);
    const attendance = attendanceMap.get(dateString);

    if (!attendance) continue;

    let record = null;
    if (Array.isArray(attendance.records) && attendance.records.length) {
      record = attendance.records.find(
        (r) => String(r.worker) === String(worker._id)
      );
    }

    if (record) {
      if (record.status === "Absent") {
        absentDays++;
        continue;
      }

      const loginMinutes = toMinutes(record.loginTime);
      const logoutMinutes = toMinutes(record.logoutTime);

      const isLate =
        loginMinutes !== null &&
        lateCutoff !== null &&
        loginMinutes > lateCutoff;

      const isEarly =
        logoutMinutes !== null &&
        earlyCutoff !== null &&
        logoutMinutes < earlyCutoff;

      if (isLate || isEarly) {
        halfDays++;
      }
      continue;
    }

    if (attendance.allPresent === true) continue;

    const isAbsent =
      Array.isArray(attendance.absentWorkers) &&
      attendance.absentWorkers.some(
        (id) => String(id) === String(worker._id)
      );

    if (isAbsent) absentDays++;
  }

  const monthlySalary = Number(worker.fixedPay?.amount) || 0;

  const dayBasis =
    fullPeriodWorkingDays > 0 ? fullPeriodWorkingDays : SALARY_DAY_DIVISOR;

  const dailyRate = monthlySalary / dayBasis;

  const prorateMidMonthJoins = Boolean(policy.prorateMidMonthJoins);

  const employedRatio =
    prorateMidMonthJoins && fullPeriodWorkingDays > 0
      ? workingDays / fullPeriodWorkingDays
      : 1;

  const proratedBase = monthlySalary * employedRatio;

  const deductionUnits = absentDays + halfDays * 0.5;
  const absenceDeduction = dailyRate * deductionUnits;

  const adjustedBasic = Math.max(0, proratedBase - absenceDeduction);

  const employedRatioRounded = Math.round(employedRatio * 10000) / 10000;

  return {
    basicSalary: roundMoney(adjustedBasic),
    attendance: {
      workingDays,
      fullPeriodWorkingDays,
      presentDays: roundMoney(
        Math.max(workingDays - absentDays - halfDays * 0.5, 0)
      ),
      absentDays,
      halfDays,
      dailyRate: roundMoney(dailyRate),
      absenceDeduction: roundMoney(absenceDeduction),
      proratedBase: roundMoney(proratedBase),
      employedRatio: employedRatioRounded,
    },
  };
};

const calculateVariableSalary = async ({ worker, periodStart, periodEnd }) => {
  const productions = await ProductProduction.find({
    date: {
      $gte: startOfDay(periodStart),
      $lte: endOfDay(periodEnd),
    },
    isActive: true,
    "workers.worker": worker._id,
  }).select("date workers");

  const ratePerKg = Number(worker.variablePay?.ratePerKg) || 0;

  let totalKg = 0;

  for (const production of productions) {
    const workerEntry = production.workers?.find(
      (item) => String(item.worker) === String(worker._id)
    );
    if (!workerEntry) continue;

    totalKg += Number(workerEntry.kg || 0);
  }

  totalKg = Math.round(totalKg * 1000) / 1000;
  const totalEarnings = Math.round(totalKg * ratePerKg * 100) / 100;

  return {
    basicSalary: totalEarnings,
    production: {
      totalKg,
      ratePerKg,
      totalEarnings,
    },
  };
};

const generateSalaries = async (req, res) => {
  try {
    const { periodStart, periodEnd, workerIds = [] } = req.body;

    if (!periodStart || !periodEnd) {
      return res.status(400).json({
        success: false,
        message: "Salary period start and end dates are required",
      });
    }

    const start = startOfDay(periodStart);
    const end = endOfDay(periodEnd);

    if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) {
      return res.status(400).json({
        success: false,
        message: "Invalid salary period dates",
      });
    }

    if (start > end) {
      return res.status(400).json({
        success: false,
        message: "Period start date cannot be after period end date",
      });
    }

    const filter = {
      status: "Active",
      joiningDate: { $lte: end },
    };

    if (Array.isArray(workerIds) && workerIds.length) {
      const invalidId = workerIds.find((id) => !isValidId(id));

      if (invalidId) {
        return res.status(400).json({
          success: false,
          message: "Invalid worker ID",
        });
      }

      filter._id = { $in: workerIds };
    }

    const workers = await Worker.find(filter);

    if (!workers.length) {
      return res.status(200).json({
        success: true,
        message: "No active workers found",
        salaries: [],
      });
    }

    const settings = await getGlobalSettings();
    const results = [];

    for (const worker of workers) {
      let calculation;

      if (worker.payType === "Fixed") {
        calculation = await calculateFixedSalary({
          worker,
          periodStart: start,
          periodEnd: end,
          settings,
        });
      } else {
        calculation = await calculateVariableSalary({
          worker,
          periodStart: start,
          periodEnd: end,
        });
      }

      // Overlap lookup — exact match is the record we'd regenerate.
      const overlapping = await Salary.findOne({
        worker: worker._id,
        isDeleted: false,
        periodStart: { $lt: end },
        periodEnd: { $gt: start },
      });

      const isExactMatch =
        overlapping &&
        overlapping.periodStart.getTime() === start.getTime() &&
        overlapping.periodEnd.getTime() === end.getTime();

      if (overlapping && !isExactMatch) {
        const os = overlapping.periodStart.toISOString().slice(0, 10);
        const oe = overlapping.periodEnd.toISOString().slice(0, 10);
        results.push({
          worker: worker._id,
          name: worker.name,
          status: "skipped",
          reason: `Period overlaps an existing salary record (${os} → ${oe}).`,
          salary: overlapping,
        });
        continue;
      }

      const existingSalary = isExactMatch ? overlapping : null;

      if (existingSalary && Number(existingSalary.paidAmount) > 0) {
        results.push({
          worker: worker._id,
          name: worker.name,
          status: "skipped",
          reason: "Salary already has payments",
          salary: existingSalary,
        });
        continue;
      }

      const basicSalary = Number(calculation.basicSalary) || 0;
      const allowances = existingSalary?.allowances || 0;
      const deductions = existingSalary?.deductions || 0;

      const netSalary = calculateNetSalary(
        basicSalary,
        allowances,
        deductions
      );

      // Never let regeneration drop net below what's already committed.
      if (existingSalary) {
        const totalCommitted =
          Number(existingSalary.paidAmount || 0) +
          Number(existingSalary.advanceAmount || 0);

        if (netSalary < totalCommitted - 0.001) {
          results.push({
            worker: worker._id,
            name: worker.name,
            status: "skipped",
            reason: `Recalculated net salary (₹${netSalary.toFixed(
              2
            )}) is below amount already paid/advanced (₹${totalCommitted.toFixed(
              2
            )}). Adjust the salary record manually or remove the advance first.`,
            salary: existingSalary,
          });
          continue;
        }
      }

      let salary;

      if (existingSalary) {
        existingSalary.payType = worker.payType;
        existingSalary.basicSalary = basicSalary;
        existingSalary.netSalary = netSalary;

        if (calculation.attendance) {
          existingSalary.attendance = calculation.attendance;
        }

        if (calculation.production) {
          existingSalary.production = calculation.production;
        }

        existingSalary.paymentStatus = calculatePaymentStatus(
          netSalary,
          existingSalary.paidAmount,
          existingSalary.advanceAmount
        );

        await existingSalary.save();
        salary = existingSalary;
      } else {
        try {
          salary = await Salary.create({
            worker: worker._id,
            payType: worker.payType,
            periodStart: start,
            periodEnd: end,
            basicSalary,
            allowances,
            deductions,
            attendance: calculation.attendance || undefined,
            production: calculation.production || undefined,
            netSalary,
            paidAmount: 0,
            paymentStatus: "Pending",
            notes: "",
          });
        } catch (createErr) {
          if (createErr.code === 11000) {
            results.push({
              worker: worker._id,
              name: worker.name,
              status: "skipped",
              reason: "Duplicate salary record already exists",
            });
            continue;
          }
          throw createErr;
        }
      }

      const populated = await Salary.findById(salary._id).populate(
        "worker",
        "workerId name phone role department payType fixedPay variablePay"
      );

      results.push({
        worker: worker._id,
        name: worker.name,
        status: existingSalary ? "updated" : "created",
        salary: populated,
      });
    }

    return res.status(200).json({
      success: true,
      message: "Salary generation completed successfully",
      salaries: results,
    });
  } catch (error) {
    console.error("[generateSalaries]", error);

    return res.status(500).json({
      success: false,
      message: "Failed to generate salaries",
      error: error.message,
    });
  }
};

module.exports = {
  createSalary,
  generateSalaries,
  getSalaries,
  getSalary,
  updateSalary,
  recordSalaryAdvance,
  deleteSalaryAdvance,
  recordSalaryPayment,
  deleteSalary,
};