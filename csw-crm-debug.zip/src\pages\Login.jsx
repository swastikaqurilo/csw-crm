import { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import {
  Eye,
  EyeOff,
  Lock,
  Mail,
  AlertCircle,
  Loader2,
  CheckCircle2,
  ArrowRight,
  Shield,
  Sparkles,
  TrendingUp,
  PackageCheck,
} from "lucide-react";
import { login } from "../api/api";
import { useAuth } from "../components/AuthContext";
import cswLogo from "../assets/cswlogo.png";
import { hashPassword } from "../utils/cryptoUtils";
import { useSearchParams } from "react-router-dom";

function Login() {
  const navigate = useNavigate();
  const location = useLocation();
  const { loginSuccess } = useAuth();

  const successMessage = location.state?.message || "";

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [searchParams] = useSearchParams();
  const isSyncRedirect = searchParams.get("reason") === "sync";
  

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (!email.trim() || !password) {
      setError("Please enter both email and password.");
      return;
    }

    try {
      setLoading(true);

      if (navigator.onLine) {
        const response = await login({
          email: email.trim(),
          password,
        });
        
        const responseData = response?.data?.data || {};
        const token = responseData.token;

        if (!token) {
          throw new Error("Invalid response from server. No token received.");
        }

        const user = responseData.user || responseData; 

        await loginSuccess(token, user, password); 

       } else {
        console.log("Offline login attempt");
        const normalizedEmail = email.trim().toLowerCase();
        
        const savedCredsStr = localStorage.getItem(`offlineCreds_${normalizedEmail}`);
        
        if (!savedCredsStr) {
          throw new Error("You have never logged in on this device. Internet is required for first-time login.");
        }

        let savedCreds;
        try {
          savedCreds = JSON.parse(savedCredsStr);
        } catch (e) {
          throw new Error("Corrupted offline data. Please log in online to fix.");
        }

        const inputHash = await hashPassword(password);
        
        if (inputHash !== savedCreds.hash) {
          throw new Error("Invalid email or password (offline mode).");
        }

        const cachedUser = savedCreds.user;

        if (!cachedUser) {
          throw new Error("No cached user data found. Please log in online once to fix this.");
        }

        const fakeToken = `offline-token-${Date.now()}`;
        await loginSuccess(fakeToken, cachedUser, null); 
        console.log("Offline login successful");
      }

      const from = location.state?.from?.pathname || "/dashboard";
      navigate(from, { replace: true });

    } catch (err) {
      console.error("Login error:", err); 
      setError(
        err?.response?.data?.message ||
        err?.message ||
        "Login failed. Please try again."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full bg-slate-50 font-sans antialiased">
      <div className="flex min-h-screen">
        <section className="relative hidden w-[48%] overflow-hidden bg-gradient-to-br from-[#020b14] via-[#001830] to-[#002244] p-12 lg:flex lg:flex-col lg:justify-between xl:p-16">

          <div className="pointer-events-none absolute -left-24 -top-24 h-[28rem] w-[28rem] rounded-full bg-sky-500/15 blur-3xl" />

          <div className="pointer-events-none absolute -bottom-32 -right-20 h-[30rem] w-[30rem] rounded-full bg-blue-600/15 blur-3xl" />

          <div className="pointer-events-none absolute left-1/2 top-1/2 h-56 w-56 -translate-x-1/2 -translate-y-1/2 rounded-full bg-cyan-400/10 blur-3xl" />

          {/* Top content */}
          <div className="relative z-10">

            {/* Logo */}
            <div className="mb-12 inline-flex items-center rounded-2xl border border-white/10 bg-white p-4 shadow-2xl">
              <img
                src={cswLogo}
                alt="Corvex Steel Wires"
                className="h-11 w-auto object-contain"
              />
            </div>

            {/* Badge */}
            <div className="inline-flex items-center gap-2 rounded-full border border-sky-400/20 bg-sky-400/10 px-3 py-1.5 text-xs font-medium text-sky-300">
              <Sparkles size={13} />
              <span>Commercial Enterprise Portal</span>
            </div>

            {/* Heading */}
            <h1 className="mt-6 max-w-lg text-4xl font-extrabold leading-tight tracking-tight text-white xl:text-5xl !text-sky-300">
              Commercial pipeline,
              <span className="block bg-gradient-to-r from-sky-300 via-cyan-200 to-blue-200 bg-clip-text text-sky-300">
                built for steel.
              </span>
            </h1>

            {/* Description */}
            <p className="mt-6 max-w-md text-base leading-relaxed text-slate-300">
              Track enquiries, close deals, and manage orders — all in one
              secure, high-performance workspace tailored for Corvex Steel
              Wires.
            </p>
          </div>

          {/* Bottom content */}
          <div className="relative z-10 space-y-6">

            {/* Feature cards */}
            <div className="grid grid-cols-2 gap-4">

              <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-4 backdrop-blur-md transition hover:border-sky-400/30 hover:bg-white/[0.07]">
                <div className="flex items-center gap-2.5">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-sky-500/20 text-sky-300">
                    <TrendingUp size={16} />
                  </div>

                  <span className="text-sm font-semibold text-white">
                    Enquiries
                  </span>
                </div>

                <p className="mt-2 text-xs leading-relaxed text-slate-400">
                  From lead generation to seamless conversion.
                </p>
              </div>

              <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-4 backdrop-blur-md transition hover:border-cyan-400/30 hover:bg-white/[0.07]">
                <div className="flex items-center gap-2.5">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-cyan-500/20 text-cyan-300">
                    <PackageCheck size={16} />
                  </div>

                  <span className="text-sm font-semibold text-white">
                    Orders
                  </span>
                </div>

                <p className="mt-2 text-xs leading-relaxed text-slate-400">
                  Dispatch status and payment tracking.
                </p>
              </div>

            </div>

            {/* Security */}
            <div className="flex items-center gap-2.5 text-xs text-slate-400">
              <Shield size={14} className="text-sky-400" />
              <span>
                Secure access · Corvex Steel Wires Workspace
              </span>
            </div>

          </div>
        </section>
        <section className="flex min-h-screen w-full flex-1 items-center justify-center bg-white px-6 py-12 sm:px-10 lg:px-14 xl:px-20">

          <div className="w-full max-w-[400px]">

            {/* Mobile logo */}
            <div className="mb-10 flex justify-center lg:hidden">
              <div className="rounded-2xl border border-slate-200 bg-white px-5 py-3 shadow-sm">
                <img
                  src={cswLogo}
                  alt="Corvex Steel Wires"
                  className="h-10 w-auto object-contain"
                />
              </div>
            </div>

            {/* Header */}
            <div className="mb-8">
              <h2 className="text-[1.7rem] font-bold tracking-tight text-slate-900">
                Welcome back
              </h2>

              <p className="mt-2 text-sm leading-relaxed text-slate-500">
                Sign in to your CSW commercial workspace.
              </p>
            </div>

            {/* Success message */}
            {successMessage && !error && (
              <div className="mb-5 flex items-start gap-3 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3.5 text-sm text-emerald-700">
                <CheckCircle2
                  size={18}
                  className="mt-0.5 shrink-0"
                />

                <span>{successMessage}</span>
              </div>
            )}

            {isSyncRedirect && !error && (
              <div className="mb-5 flex items-start gap-3 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3.5 text-sm text-amber-800">
                <AlertCircle size={18} className="mt-0.5 shrink-0" />
                <span>
                  <strong>Session Expired.</strong> Please log in again to sync your offline changes.
                </span>
              </div>
            )}

            {/* Error message */}
            {error && (
              <div className="mb-5 flex items-start gap-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3.5 text-sm text-red-700">
                <AlertCircle
                  size={18}
                  className="mt-0.5 shrink-0"
                />

                <span>{error}</span>
              </div>
            )}

            <form
              onSubmit={handleSubmit}
              className="space-y-5"
            >

              {/* Email */}
              <div>
                <label
                  htmlFor="email"
                  className="mb-1.5 block text-xs font-semibold text-slate-700"
                >
                  Email address
                </label>

                <div className="relative">
                  <Mail
                    size={16}
                    className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"
                  />

                  <input
                    id="email"
                    type="email"
                    autoComplete="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@corvex.com"
                    disabled={loading}
                    className="h-12 w-full rounded-xl border border-slate-200 bg-white pl-10 pr-4 text-sm text-slate-800 shadow-sm outline-none transition placeholder:text-slate-400 hover:border-slate-300 focus:border-[#002244] focus:ring-4 focus:ring-[#002244]/10 disabled:cursor-not-allowed disabled:bg-slate-50"
                  />
                </div>
              </div>

              {/* Password */}
              <div>
                <div className="mb-1.5 flex items-center justify-between">
                  <label
                    htmlFor="password"
                    className="block text-xs font-semibold text-slate-700"
                  >
                    Password
                  </label>

                  <button
                    type="button"
                    onClick={() => navigate("/forgot-password")}
                    className="text-[11px] font-semibold text-[#002244] transition hover:text-[#00345f] hover:underline"
                  >
                    Forgot password?
                  </button>
                </div>

                <div className="relative">
                  <Lock
                    size={16}
                    className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"
                  />

                  <input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    autoComplete="current-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    disabled={loading}
                    className="h-12 w-full rounded-xl border border-slate-200 bg-white pl-10 pr-11 text-sm text-slate-800 shadow-sm outline-none transition placeholder:text-slate-400 hover:border-slate-300 focus:border-[#002244] focus:ring-4 focus:ring-[#002244]/10 disabled:cursor-not-allowed disabled:bg-slate-50"
                  />

                  <button
                    type="button"
                    onClick={() => setShowPassword((value) => !value)}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 transition hover:text-slate-600"
                    tabIndex={-1}
                    aria-label={
                      showPassword
                        ? "Hide password"
                        : "Show password"
                    }
                  >
                    {showPassword ? (
                      <EyeOff size={16} />
                    ) : (
                      <Eye size={16} />
                    )}
                  </button>
                </div>
              </div>

              {/* Submit */}
              <button
                type="submit"
                disabled={loading}
                className="group inline-flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-[#002244] text-sm font-semibold text-white shadow-md shadow-[#002244]/20 transition hover:bg-[#00345f] hover:shadow-lg hover:shadow-[#002244]/25 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {loading ? (
                  <>
                    <Loader2
                      size={16}
                      className="animate-spin"
                    />
                    Signing in...
                  </>
                ) : (
                  <>
                    Sign in

                    <ArrowRight
                      size={16}
                      className="transition-transform group-hover:translate-x-0.5"
                    />
                  </>
                )}
              </button>
            </form>

            {/* Register */}
            <p className="mt-8 text-center text-sm text-slate-500">
              Need an account?{" "}
              <Link
                to="/register"
                className="font-semibold text-[#002244] transition hover:text-[#00345f] hover:underline"
              >
                Create admin
              </Link>
            </p>

            {/* Footer */}
            <p className="mt-8 text-center text-xs text-slate-400">
              © {new Date().getFullYear()} Corvex Steel Wires · Authorized
              access only
            </p>

          </div>
        </section>
      </div>
    </div>
  );
}

export default Login;